app.component('payrollComponent', {
  bindings: {},
  templateUrl: './src/components/payroll-component/payroll.component.html',
  controller: payrollController
});

function payrollController() {}
