var app = angular.module('mainApp', [
  'ngMaterial',
  'ngMessages',
  'ui.router',
  'chart.js'
]);
